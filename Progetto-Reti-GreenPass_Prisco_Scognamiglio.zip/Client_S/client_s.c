#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include<errno.h>
#include "wrapper.h"




char buff[1024];
struct sockaddr_in serverAddr;//dichiaro la struttura del server 

int main(int argc, char *argv[])
{
	

	struct sockaddr_in serverAddr;//dichiaro la struttura del server 
	//AF_INET indica il dominio della socket(iPV4)(famiglia)
	//SOCK_STREAM E’ un canale bidirezionale, sequenziale affidabile.I dati
	//vengono ricevuti e trasmessi come un flusso continuo .
	//PROTOCOL protocollo utilizzato nella socket (0 default)
	int clientFD = socket(AF_INET, SOCK_STREAM, 0);

	char buff[1024];
	char ID[1024] ;//scelta


	serverAddr.sin_family = AF_INET;// inizializzo la famiglia AF_INET (iPv4)
	serverAddr.sin_port = htons(8082);//inizializzo il numero di porta 8080.htons conversione host to network
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");//inizializzo l'indirizzo ip su 127.0.0.1


	//connect stabilisce una connessione fra due socket  clientFD all’indirizzo serveraddr. 
	//Il terzo argomento è la dimensione in byte della struttura.
	//Restituisce: 0 Successo -1 Errore.
	if (connect(clientFD, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
	{	printf("errore .\n");
		exit(-1);
	}	
	
	printf("\nConnessione al server G stabilita.\n");
	strcpy(buff,"s");
	FullWrite(clientFD, buff,sizeof(buff));// invio s per dire che sono un client s

	printf("\nInserire ID tessera sanitaria.\n");
	scanf("%s", ID);
	FullWrite(clientFD, ID,sizeof(ID));//mando l'id della tessera
	FullRead(clientFD, buff,sizeof(buff));//ricevo l'esito
	
	if(strcmp(buff,"n")==0)//l'id non e' presente
	printf("\nID errato\n");

	if(strcmp(buff,"y")==0)
	printf("\nGreen pass invalidato\n");

	if(strcmp(buff,"v")==0)
	printf("\nGreen pass valido\n");
	
	
		

	close(clientFD);
}