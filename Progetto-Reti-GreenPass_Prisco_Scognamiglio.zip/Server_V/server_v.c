#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <arpa/inet.h>
#include <errno.h>
#include "wrapper.h"
int n=0;

struct serverv
{
	char id[1024];
	char stato[1024];
	int valido;
}server[1024];

void close_server()
{
	exit(0);
}


void * func(void * s_fd)
{
	char buff[1024];
	char ID[1024];
	int *fd=(int*)s_fd;	
  int fd_g,fd_v;

  while(1){
  	char esito[1024];
  	FullRead(*fd,buff,sizeof(buff));//ricevo le richeste del centro vaccinale e del server g
	
	if(buff[0]=='g'){//se ho ricevuto il carattere g gestisco la richiesta del server g
      fd_g=*fd;//assegno il descrittore per comunicare con il server g
      printf("Richiesta server G \n");
      FullRead(fd_g,buff,sizeof(buff));//ricevo la richiesta dei client s e t
      

      if(buff[0]=='s')//gestisco la richiesta di validita
      	{ 
      	printf("\nRichiesta validita' Green pass \n"); 
      		strcpy(esito,"n");
      	FullRead(fd_g,buff,sizeof(buff));//ricevo l'id tessera
		
		while(1){
			for(int i=0;i<n;i++)
		{    
			if(strcmp(buff,server[i].id)==0)//verifico se è presente   
			{		strcpy(esito,"y");//assegno il carattere y per dire che non e' valido
      	if(server[i].valido==1)//verifico se è valido
						strcpy(esito,"v");
			}	
		   
		}
		
		FullWrite(fd_g, esito,sizeof(esito));//mando l'esito al server g
		}  	
      }
     
       if(buff[0]=='t')
      {
        printf("\nRichiesta  modifica di stato \n");
      	char esito[1024];
       	FullRead(fd_g,buff,sizeof(buff));//ricevo l'id della tessera dal server g
				strcpy(ID,buff);
		    FullRead(fd_g,buff,sizeof(buff));//ricevo la richiesta
				strcpy(esito,"n");

		while(1){
			for(int i=0;i<n;i++)
		{ 
			if(strcmp(ID,server[i].id)==0)
			{ 
				strcpy(esito,"y");//assegno y se l'id e' presente
				
				if(strcmp(buff,"quarantena")==0)//se la richiesta è di quarantena
					{ 
						server[i].valido=0;//invalido il green pass
						if(strcmp(server[i].stato,"quarantena")==0)
							{
							strcpy(esito,"gia quarantena");//se e' gia' in quarantena
							}
						else 
							strcpy(server[i].stato,"quarantena");//altrimenti cambio lo stato in quarantena
					} 

				if(strcmp(buff,"guarigione")==0)//se voglio ripristinare il green pas
				{	
					server[i].valido=1;//assegno 1 per ripristinare il green pass
						if(strcmp(server[i].stato,"vaccinato")==0)// se voglio mettere una guarigione con id non contagiato
					{
						strcpy(esito,"non contagiato");
					}
				
				}
				

		    }
		    
		}
		
		FullWrite(fd_g, esito,sizeof(esito));//mando l'esito al server g

		}

		
    }
  
  	}


	
  if(buff[0]=='v'){//gestisco la richiesta del centro vaccinale
    	fd_v=*fd;//assegno il descrittore per comunicare con il centro vaccinale
 			int flag=0;
 			printf("Richiesta periodo di validita' centro vaccinale \n");
    	FullRead(fd_v,buff,sizeof(buff));//ricevo id tessera dal centro vaccinale
 
    
    while(1){
    	for(int i=0;i<n;i++)
    		{
    			if(strcmp(server[i].id,buff)==0){
    			flag=1;//metto il flag a 1 perchè l'id e' gia' stato registrato
    			strcpy(buff,"n");
    		}
    		}
    		if(flag==0){//l'id non e' gia' stato inserito quindi lo memorizzo
    			strcpy(server[n].id,buff);
    			strcpy(buff,"y");
    			server[n].valido=1;
    			strcpy(server[n].stato,"vaccinato");

    		}
	
    FullWrite(fd_v,buff,sizeof(buff));//mando l'esito
    
    if(server[n].valido==1){//se è stato memorizzato l'id
    	FullRead(fd_v,buff,sizeof(buff));//ricevo la validita'
    	printf("%s\n",buff);
  }
  else
  	printf("\nID tessera presente");
      n++;
	}
	}
	
}
	pthread_exit(fd);
}

int main()
{  
	pthread_t *thread;

   
   int i=0;
	struct sockaddr_in serverAddr;//dichiaro la struttura del server
	//AF_INET indica il dominio della socket(iPV4)(famiglia)
	//SOCK_STREAM E’ un canale bidirezionale, sequenziale affidabile.I dati
	//vengono ricevuti e trasmessi come un flusso continuo .
	//PROTOCOL protocollo utilizzato nella socket (0 default)
	int listen_fd = socket(AF_INET, SOCK_STREAM, 0);//dichiaro la socket nella variabile listen_fd
   int *s_fd;

	serverAddr.sin_family = AF_INET;// inizializzo la famiglia AF_INET (iPv4),famiglia dei protocolli da usare.
	serverAddr.sin_port = htons(8081);//inizializzo il numero di porta . htons fa una conversione host to network
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);// inizializzo l'indirizzo IP (any=qualsiasi)
	
	struct sockaddr_in client_addr;
	socklen_t len;//dimensione struct contenete indirizzo


	//mi serve per evitare l errore nella bind 
	int enable=1;//variabile  serve per evitare errore bind 
	signal(SIGTSTP,close_server);//segnale di arresto
    setsockopt(listen_fd,SOL_SOCKET,SO_REUSEADDR,&enable,sizeof(int));//permette di impostare le opzioni del socket 
    //Reuseaddr permette il riutilizzo degli indirizzi locali 


// utilizzo bind  per la socket per assegnare un indirizzo alla socketaddr e restituisce -1 se la bind è fallita altrimenti 0 se è corretta
	//primo argomento è un file descriptor ottenuto da una precedente chiamata a
	//socket, secondo l’indirizzo(locale) del socket,terzo dimensione  struttura che lo contiene.
	if (bind(listen_fd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
		exit(-1);

	//si mette in ascolto di nuove connessioni sul descrittore listen_fd
	//1024 lunghezza coda di attesa.La funzione Restituisce 0 o -1.
	if (listen(listen_fd, 1024) == -1)
		exit(-1);
		
printf("\nServer V in ascolto sulla porta 8081\n\n");

	while (1)
	{
		
		s_fd=(int*)malloc(sizeof(int));	

		//Accetta le connessioni arrivate sul descrittore che si era messo in ascolto. Il secondo
		//terzo parametro  memorizzano l’indirizzo del client che ha effettuato la connessione,puo essere  NULL.
		// errore restituisce -1, successo restituisce un nuovo descrittore  utilizzato per la comunicazione
		//mentre quello vecchio (listen_fd) resta ancora in ascolto.
		*s_fd = accept(listen_fd,(struct sockaddr *) &client_addr,&len);//assegno a *s_fd  il descrittore ricevuto dall accept 
		thread = (pthread_t *)malloc(sizeof(pthread_t));//alloco memoria thread
		int fd_client=*s_fd;
		free(s_fd);//libero descrittore 
		
		
		pthread_create(thread,NULL,(void*)func,&fd_client);//delego la gestione ad un thread indipendente
		
			
	}

}
