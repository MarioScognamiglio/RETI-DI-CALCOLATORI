#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include<errno.h>
#include "wrapper.h"




char buff[1024];
struct sockaddr_in serverAddr;//dichiaro la struttura del server 

int main(int argc, char *argv[])
{
	

	struct sockaddr_in serverAddr;//dichiaro la struttura del server 
	//AF_INET indica il dominio della socket(iPV4)(famiglia)
	//SOCK_STREAM E’ un canale bidirezionale, sequenziale affidabile.I dati
	//vengono ricevuti e trasmessi come un flusso continuo .
	//PROTOCOL protocollo utilizzato nella socket (0 default)
	int clientFD = socket(AF_INET, SOCK_STREAM, 0);

	char buff[1024];
	char ID[1024] ;//scelta


	serverAddr.sin_family = AF_INET;// inizializzo la famiglia AF_INET (iPv4)
	serverAddr.sin_port = htons(8082);//inizializzo il numero di porta 8082.htons conversione host to network
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");//inizializzo l'indirizzo ip su 127.0.0.1


	//connect stabilisce una connessione fra due socket  clientFD all’indirizzo serveraddr. 
	//Il terzo argomento è la dimensione in byte della struttura.
	//Restituisce: 0 Successo -1 Errore.
	if (connect(clientFD, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
	{	
		printf("errore .\n");
		exit(-1);
	}	
	
	printf("\nConnessione al server G stabilita\n\n");
	strcpy(buff,"t");
	FullWrite(clientFD, buff,sizeof(buff));// invio t per dire che sono un client t

	printf("Inserire ID tessera sanitaria\n");
	scanf("%s", ID);
	FullWrite(clientFD, ID,sizeof(ID));
	printf("\nModifica lo stato in:\n[1]Guarigione\n[2]Quarantena\n\n");
	scanf("%s", buff);

	FullWrite(clientFD, buff,sizeof(buff));//manda l'id tessera
	FullRead(clientFD, buff,sizeof(buff));//ricevo esito
	
	if(strcmp(buff,"y")==0)
	printf("\nModifica avvenuta con successo\n");
	
	if(strcmp(buff,"n")==0)
	printf("\nID non valido\n");

if(strcmp(buff,"non contagiato")==0)
	printf("\nIl paziente non e' stato contagiato\n");	

if(strcmp(buff,"gia quarantena")==0)
	printf("\nIl paziente e' gia in quarantena \n");	


	close(clientFD);
}