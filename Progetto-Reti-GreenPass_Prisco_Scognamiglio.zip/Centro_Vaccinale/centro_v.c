#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <pthread.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <signal.h>
#include <string.h>
#include <arpa/inet.h>
#include <errno.h>
#include "wrapper.h"

void close_server()
{
exit(0);
}
void * func(void * s_fd)
{	char buff[1024];
	char ID_tessera[1024];
	int *fd=(int*)s_fd;	
    	
	FullRead(*fd,buff,sizeof(buff));
	strcpy(ID_tessera,buff);


	struct sockaddr_in serverAddr;
	int serverV_FD = socket(AF_INET, SOCK_STREAM, 0);

	serverAddr.sin_family = AF_INET;// inizializzo la famiglia AF_INET (iPv4)
	serverAddr.sin_port = htons(8081);//inizializzo il numero di porta 8081.htons conversione host to network
	serverAddr.sin_addr.s_addr = inet_addr("127.0.0.1");

	//connect stabilisce una connessione fra due socket al  serverV all’indirizzo serveraddr. 
	//Il terzo argomento è la dimensione in byte della struttura.
	//Restituisce: 0 Successo -1 Errore.
	if (connect(serverV_FD, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
	{	printf("errore connect\n");
		exit(-1);
	}	
	printf("Connessione con il server V stabilita.\n");
	strcpy(buff,"v");
	FullWrite(serverV_FD,buff,sizeof(buff));
	FullWrite(serverV_FD,ID_tessera,sizeof(ID_tessera));
	FullRead(serverV_FD,buff,sizeof(buff));
	FullWrite(*fd,buff,sizeof(buff));
	if(buff[0]=='y')
	{
    strcpy(buff,"6 mesi");
	FullWrite(serverV_FD,buff,sizeof(buff));
	
	}
	
	pthread_exit(fd);
}

int main()
{  
	pthread_t *thread;

   
   int i=0;
	struct sockaddr_in serverAddr;//dichiaro la struttura del server
	//AF_INET indica il dominio della socket(iPV4)(famiglia)
	//SOCK_STREAM E’ un canale bidirezionale, sequenziale affidabile.I dati
	//vengono ricevuti e trasmessi come un flusso continuo .
	//PROTOCOL protocollo utilizzato nella socket (0 default)
	int listen_fd = socket(AF_INET, SOCK_STREAM, 0);//dichiaro la socket nella variabile listen_fd
   int *s_fd;

	serverAddr.sin_family = AF_INET;// inizializzo la famiglia AF_INET (iPv4),famiglia dei protocolli da usare.
	serverAddr.sin_port = htons(8080);//inizializzo il numero di porta . htons fa una conversione host to network
	serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);// inizializzo l'indirizzo IP (any=qualsiasi)
	
	struct sockaddr_in client_addr;
	socklen_t len;//dimensione struct contenete indirizzo


	//mi serve per evitare l errore nella bind 
	int enable=1;//variabile  serve per evitare errore bind 
	signal(SIGTSTP,close_server);//segnale di arresto 
    setsockopt(listen_fd,SOL_SOCKET,SO_REUSEADDR,&enable,sizeof(int));//permette di impostare le opzioni del socket, si utilizza dopo socket e prima di bind
    //Reuseaddr permette il riutilizzo degli indirizzi locali 




    // utilizzo bind  per la socket per assegnare un indirizzo alla socketaddr e restituisce -1 se la bind è fallita altrimenti 0 se è corretta
	//primo argomento è un file descriptor ottenuto da una precedente chiamata a
	//socket, secondo l’indirizzo(locale) del socket,terzo dimensione  struttura che lo contiene.
	if (bind(listen_fd, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) == -1)
		exit(-1);

	//si mette in ascolto di nuove connessioni sul descrittore listen_fd
	//1024 lunghezza coda di attesa.La funzione Restituisce 0 o -1.
	if (listen(listen_fd, 1024) == -1)
		exit(-1);
		
printf("Server  in ascolto sulla porta 8080\n\n");

	while (1)
	{
		
		s_fd=(int*)malloc(sizeof(int));	//allocazione s_fd

		//Accetta le connessioni arrivate sul descrittore che si era messo in ascolto. Il secondo
		//terzo parametro  memorizzano l’indirizzo del client che ha effettuato la connessione,puo essere  NULL.
		// errore restituisce -1, successo restituisce un nuovo descrittore  utilizzato per la comunicazione
		//mentre quello vecchio (listen_fd) resta ancora in ascolto.
		*s_fd = accept(listen_fd,(struct sockaddr *) &client_addr,&len);//assegno a *s_fd  il descrittore ricevuto dall accept 
		
		thread = (pthread_t *)malloc(sizeof(pthread_t));//alloco memoria thread
		int fd_client=*s_fd;
		free(s_fd);//libero descrittore 
		
		
		pthread_create(thread,NULL,(void*)func,&fd_client);//delego la gestione ad un thread indipendente
		
			
	}

}


